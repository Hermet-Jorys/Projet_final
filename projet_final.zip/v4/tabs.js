function tabsLeft(evt, testbenchNAME) {
    
  // Declarer les variables
    var i, tabcontent, tablinks;
  
    //Récupérer les éléments avec la  class="affichage_onglet_g" et les cacher
    tabcontent = document.getElementsByClassName("affichage_onglet_g");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  

    //Récupérer les éléments avec la  class="tabs_left" et enlever la classe active
    tablinks = document.getElementsByClassName("tabs_left");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Montrer l'onglet actif en lui ajoutant la classe active
    document.getElementById(testbenchNAME).style.display = "block";
    evt.currentTarget.className += " active";
  } 

function tabsRight(evt, designNAME) {
    // Declarer les variables
    var i, tabcontent, tablinks;
  
    //Récupérer les éléments avec la  class="affichage_onglet_d" et les cacher
    tabcontent = document.getElementsByClassName("affichage_onglet_d");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  
    //Récupérer les éléments avec la  class="tabs_right" et enlever la classe active
    tablinks = document.getElementsByClassName("tabs_right");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Montrer l'onglet actif en lui ajoutant la classe active
    document.getElementById(designNAME).style.display = "block";
    evt.currentTarget.className += " active";
}

function tabsBottom(evt, bottomPannel) {
    // Declarer les variables
    var i, tabcontent, tablinks;
  
    //Récupérer les éléments avec la  class="bottomTabsPanel" et les cacher
    tabcontent = document.getElementsByClassName("bottomTabsPanel");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
  //Récupérer les éléments avec la  class="tabs_bottom" et enlever la classe active
    tablinks = document.getElementsByClassName("tabs_bottom");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
  
    // Montrer l'onglet actif en lui ajoutant la classe active
    document.getElementById(bottomPannel).style.display = "block";
    evt.currentTarget.className += " active";
}


/******** dialog *********** */


// afficher le dialog au click
var addOngletG = document.getElementById('add_onglet_g');
addOngletG.addEventListener('click', ()=>{
    dialogOpen('g');
});


var addOngletD = document.getElementById('add_onglet_d');
    addOngletD.addEventListener('click', ()=>{
        dialogOpen('d');
});

//gestion du dialog
function dialogOpen(s){
    var closeButton = document.getElementById('close_dialog');
    var dialog = document.getElementById('Dialog');
    var createFile = document.getElementById('test_bench_add_button');
    var corps = document.getElementById('content');
    var inputFile = document.getElementById('input_file');
    var error_message = document.getElementById('error_message');
    var side=s;
    
    //ajouter des effets sur l'affichage
    corps.style.opacity = "0.5";
    dialog.open = true;
    
    
    if (side=='g'){

      // ajouter un fichier depuis l'ordinateur
     
        document.getElementById("boutonCharger").addEventListener('keyup',function dropG() {
          chargerFichier("testBenchUploadFile", 'g');
          document.getElementById("boutonCharger").removeEventListener('keyup',dropG)
    });
      document.getElementById("boutonCharger").addEventListener('click',function dropG() {
          chargerFichier("testBenchUploadFile", 'g');
          document.getElementById("boutonCharger").removeEventListener('click',dropG)
      });
     
      
    
      // ajouter au clique
      createFile.addEventListener('click',function gClique(){
        add();
        if (error_message.innerHTML ==''){
        createFile.removeEventListener('click',gClique);
      }});
        
    } else {
        
          // ajouter un fichier depuis l'ordinateur
          document.getElementById("boutonCharger").addEventListener('keyup',function drop() {
            chargerFichier("testBenchUploadFile", 'd');
            document.getElementById("boutonCharger").removeEventListener('keyup',drop);
            
        });
          document.getElementById("boutonCharger").addEventListener('click',function dropD() {
            chargerFichier("testBenchUploadFile", 'd');
            document.getElementById("boutonCharger").removeEventListener('click',dropD);

        });
   ;
      
        // ajouter au clique
        createFile.addEventListener('click',function dClique(){
          add2();
          if (error_message.innerHTML ==''){
          createFile.removeEventListener('click',dClique);
        }});
    }

        
    
    // fermer la fenêtre quand on clique sur la croix
    closeButton.addEventListener('click',()=>{
      closeDialog();
    });
    
    };

// ajouter un onglet à gauche
function add(){
  var inputFile = document.getElementById('input_file');
  var error_message = document.getElementById('error_message');
  var createFile = document.getElementById('test_bench_add_button');

  if (inputFile.value == ''){
    error_message.innerHTML='Le fichier doit au moins contenir un caractère';
    error_message.style.display='inline-block';
  } else {
    if (!!document.getElementById(inputFile.value) == true){
      error_message.innerHTML='Ce nom de fichier existe déjà, veuillez en choisir un autre';
      error_message.style.display='inline-block';
    }}
  if (inputFile.value != '' && !!document.getElementById(inputFile.value) != true){

  
    NewOnglet('g',inputFile.value);
    createFile.removeEventListener('click',add);
    designCode(inputFile.value,list);

    closeDialog();
  }
};

// ajouter un onglet à droite
function add2(){
  var inputFile = document.getElementById('input_file');
  var error_message = document.getElementById('error_message');
  var createFile = document.getElementById('test_bench_add_button');
  
  if (inputFile.value == ''){
    error_message.innerHTML='Le fichier doit au moins contenir un caractère';
    error_message.style.display='inline-block';
  } else {
    if (!!document.getElementById(inputFile.value) == true){
      error_message.innerHTML='Ce nom de fichier existe déjà, veuillez en choisir un autre';
      error_message.style.display='inline-block';
    }
    else{
      
    NewOnglet('d',inputFile.value);
    designCode(inputFile.value,list);
    closeDialog();

}}};




// fermer le dialog 

function closeDialog(){
    var closeButton = document.getElementById('close_dialog');
    var dialog = document.getElementById('Dialog');
    var inputFile = document.getElementById('input_file');
    var createFile = document.getElementById('test_bench_add_button');
    var error_message = document.getElementById('error_message');
    var corps = document.getElementById('content');
    
    inputFile.value = '';
    error_message.innerHTML='';
    error_message.style.display='block';
    corps.style.opacity = "1.0";
    dialog.open = false;
    document.getElementById("boutonCharger").className="file_drop cacher";
 


}

// récuperer le drop d'un fichier  
function chargerFichier(idInputFile, idSortie) {

      var error_message = document.getElementById('error_message');
      var corps = document.getElementById('content');
      var side = idSortie;

      if (typeof window.FileReader !== "function") {
          alert("L’API file n’est pas encore supportée par votre navigateur.");
          return;
      }
  
      entree = document.getElementById(idInputFile);
      if (!entree.files[0]) {
          alert("S’il vous plaît sélectionnez un fichier avant de cliquer sur «Confirmer».");
      } else {
          fichier = entree.files[0];
          fr = new FileReader();
          fr.onload = function () {
              
              NewOnglet(side,fichier.name,fr.result);
              designCode(fichier.name);
          };
          fr.readAsText(fichier);
          closeDialog();

      };
     
  }

document.getElementById('file_drop').addEventListener('click',()=>{
  document.getElementById("boutonCharger").className="file_drop";
});


// ajouter un onglet au clic
function NewOnglet(side ,name,innercode = 0){  

  
  if (side == 'g'){
    if (innercode != 0){
      var contenue = "<div id='test_"+name+"'class='affichage_onglet_g'><textarea class='editor' id='"+name+"'>"+innercode+"</textarea></div>"
    } else{
      var contenue = "<div id='test_"+name+"'class='affichage_onglet_g'> <textarea class='editor' id='"+name+"'>//Rentrez le code ici</textarea></div>"
    };
    var txt1 = ` <li class="tab_list" id="`+name+`_li"><button id="onglet_`+name+`" class="tabs_left ui_tabs" onclick="tabsLeft(event,'test_`+name+`')" ondblclick="rename('`+name+`')">`+name+`</button> </li>`;
    $("#add_onglet_g").before(txt1);
    $("#test_pannel").append(contenue);
  } else {
    if (innercode != 0){
      var contenue2 = "<div id='design_"+name+"'class='affichage_onglet_d'><textarea class='editor' id='"+name+"'>"+innercode+"</textarea></div>"
    } else{
      var contenue2 = "<div id='design_"+name+"'class='affichage_onglet_d'><textarea class='editor' id='"+name+"'>//Rentrez le code ici</textarea></div>";
  
    };
    var txt2 = ` <li class="tab_list" id="`+name+`_li"><button id="onglet_`+name+`" class="tabs_right ui_tabs" onclick="tabsRight(event,'design_`+name+`')" ondblclick="rename('`+name+`')">`+name+`</button> </li>`;
    $("#add_onglet_d").before(txt2);
    $("#design_pannel").append(contenue2);
  }
 

};


// changer le nom de l'onglet ou le suprimer

function rename(name){
  var closeButton = document.getElementById('close_dialog2');
  var dialog = document.getElementById('Dialog_rename');
  var corps = document.getElementById('content');
  var inputRename = document.getElementById('rename_file');
  var removeFile = document.getElementById('remove_file');
  var span = document.getElementById('span_delete');
  var child = document.getElementById(name+'_li');


  
  corps.style.opacity = "0.5";
  dialog.open = true;
  inputRename.placeholder = name;
  OngletName = 'onglet_'+name;


  //empecher la suppression des premiers onglets
  if (name=='design.vdh'|| name=='testbench.vhd'){
    span.style.display='none';
    span.visibility='hidden';
    document.getElementById('h4').innerText='';
  }else{
    span.style.display='inline-block';
    span.visibility='visible';
    document.getElementById('h4').innerText='ou';
  
  
    //Supprimer le fichier
    removeFile.addEventListener('click',function supp(){
    
    
    child.remove();
    if (document.getElementById('design_'+name)){
      document.getElementById('design_'+name).remove()
    }else{
      if(document.getElementById('test_'+name)){
        document.getElementById('test_'+name).remove()
    };}
    closeDialog2();
    removeFile.removeEventListener('click',supp);
   
    
    
  })
  };
  
 // renommer le fichier
 function f2(){
    var inputRename = document.getElementById('rename_file');
    if(inputRename.value==''){
      document.getElementById('error_message2').innerHTML='Veuillez rentrez un nom de fichier';
    } else{
      document.getElementById(OngletName).innerHTML=inputRename.value;
      document.getElementById('rename_button').removeEventListener('click', f2);
      closeDialog2();
    }
};
  // au clique
  document.getElementById('rename_button').addEventListener('click',()=>{
    f2();

  });
  // bouton entrer
  document.getElementById('rename_file').addEventListener('keydown',(e)=>{
    if (e.key=='Enter'){
      f2();
    }
    
  })
  

 

  // fermez le dialogue 2
  closeButton.addEventListener('click',()=>{
    child=null;
    closeDialog2();
  });

};


// fermer le dialogue numéro 2
function closeDialog2(){
  var dialog = document.getElementById('Dialog_rename');
  var corps = document.getElementById('content');
  var error_message = document.getElementById('error_message2');
  var inputRename = document.getElementById('rename_file');
  var removeFile = document.getElementById('remove_file');
  
  inputRename.value = '';
  error_message.innerHTML='';
  corps.style.opacity = "1.0";
  dialog.open = false;
  
 
};
