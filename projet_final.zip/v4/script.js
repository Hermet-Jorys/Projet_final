// envoyer une requète au serveur
function loadXMLDoc(code)
{   
    
    document.getElementById("results").innerHTML ='';
    var req = new XMLHttpRequest();
    req.onreadystatechange = function()
    {   ''
        if (req.readyState == 4)
        {
            if (req.status !=200)
            {  
                //Gestion des erreurs serveurs
                document.getElementById("results").innerHTML = req.responseText;
            }
            else
            { 
              // Gestion reception de la réponse du serveur
              if (req.response.split(' ')[0]=='Erreur'){
                document.getElementById("results").innerHTML +=req.responseText
                }else{
              if (document.getElementById("results").innerHTML ==''){
                
                document.getElementById("results").innerHTML = 'La compilation des fichiers est réussie'
                downloadFile('resultat.vcd',req.responseText)
                
              }}}
        }
        
            
          
    }

    req.open('POST', 'http://localhost:5000/')
    req.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
    var un = JSON.stringify(code);
    var postVars = un;
    req.send(postVars)
    
    return false
};

function downloadFile(filename, text){
  
    var name = filename;
    var txt =text

    // Commencé le télécargement du fichier 
    document.getElementById("sv_btn").addEventListener("click", ()=>{
        
      // Générer le fichier télécharger
        download(name, txt);
    }, false);

   
}

function download(filename,text){
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);

  element.style.display = 'none';
  document.body.appendChild(element);

  element.click();

  document.body.removeChild(element);
};

// télécharger les fichiers écrits
function dl(){
  var code =document.getElementsByClassName('editor');
  var logo = document.getElementById('logo_load');
  logo.style.display='inherit';
  logo.style.visibility='visible';
  
  
    var zip = new JSZip();
   
  // récupérer tous les codes et les ajouter au zip
  for (i=0;i< code.length;i++){
      var contenue= list[""+code[i].id+""].getValue();
      var nom = code[i].parentElement.id;
      
      zip.file(nom, contenue);
      
    };

    zip.generateAsync({
      type: "base64"
  }).then(function(content) {
      window.location.href = "data:application/zip;base64," + content;
  }); 

    setTimeout(()=>{
      logo.style.display='none';
      logo.style.visibility='hidden';
    }, 3000);
};


// Lancer la compilation avec les touches CTRL+ENTER
document.addEventListener('keydown',(e)=>{
  if (e.ctrlKey && e.key == 'Enter') {
    
    nb();
  };
  
})

