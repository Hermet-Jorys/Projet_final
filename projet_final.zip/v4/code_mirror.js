// recupération code
var list=new Object();

function designCode(id,list){
    var list = list
    if (typeof(id) != 'string'){
        var name = JSON.stringify(value);
    }
    else{
        var name = id;
    }
    var editor = CodeMirror.fromTextArea( document.getElementById(name),{
        mode: "vhdl",
        theme: "paraiso-light",
        lineNumbers: true,
        autoCloseTags: true,
        autofocus: false,

    });
    list[id] = editor;


    
   
};
designCode("testbench.vhd",list);
designCode("design.vdh",list);




// récupérer le code des textarea au clic et lancer la requète
function nb(){
    var inputEntity = document.getElementById('nom_compo');
    var codeSent = new Object();
    var code =document.getElementsByClassName('editor');
    

    // récupérer tous les codes 
    for (i=0;i< code.length;i++){
    codeSent[code[i].id]= list[""+code[i].id+""].getValue();
    };
    if (inputEntity.value==''){
      alert("Il faut rentrer le nom de l'entité pour la compilation");
    }else{
    codeSent["entity"]=inputEntity.value;
  

    //envoyer la requète
    loadXMLDoc(codeSent);
    };
    
    


};

