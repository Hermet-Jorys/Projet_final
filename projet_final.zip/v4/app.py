# Import the server module

import http.server
from io import BytesIO
import json
from os import path, pipe,remove
from struct import unpack
from types import CodeType
import subprocess 





# Définir le nom

HOST = "localhost"

# Définir le numéro

PORT = 5000

def affichage(self,data):
        response = BytesIO()
        result =  data.stderr
        if data.stdout !='':
            result +=data.stdout
        
        response.write(b'Erreur de compilation : ')
        response.write(result.encode('utf-8'))
        self.wfile.write(response.getvalue())
        self.send_response(200)
        self.end_headers()
    
       



# Definir les actions du serveur

class PythonServer(http.server.SimpleHTTPRequestHandler):

    
    def do_GET(self):

        if self.path == '/':

            self.path = 'index2.html'

        return http.server.SimpleHTTPRequestHandler.do_GET(self)
 

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length).decode('utf-8') 
        dico = json.loads(body)

        
        entiy = False
        erreur=False

        # parcourir les données reçus sous forme de dict  
        for cle,valeur in dico.items():
            
            # definir le nom de l'entité
            if cle=='entity':
                entity=valeur

            else:

                # créer les fichiers
                with open(cle,'w') as f:
                    f.write(valeur)

                # compiler chacun des fichiers
                res=subprocess.run(['ghdl','-a',cle],capture_output=True,text=True)
                if res.returncode == 1 or res.stdout !='':
                    affichage(self,res)
                    erreur=True
                    
        
        # Créer le fichier résultat
        compilation =subprocess.run(['ghdl','-e',entity],capture_output=True,text=True)
        if compilation.returncode == 1 :
            affichage(self,compilation)
            erreur=True
           
        else :
            final =subprocess.run(['ghdl','-r',entity,'--vcd=result.vcd'],capture_output=True,text=True)
            
            # Vérifier si une erreur est présente ou si une assertion est fausse
            if final.returncode==1 or final.stdout !='':
                affichage(self,final)
                erreur=True
        
        try :
            with open('result.vcd','r')as f:
                resultat=f.read()
            
            if erreur==False:
                self.send_response(200)
                self.end_headers()
                response = BytesIO()
                response.write(resultat.encode('utf-8'))
                self.wfile.write(response.getvalue())

            # supprimer les fichiers crées
            item=[]
            item.append(entity)
            point_e= list(entity)
            point_e.insert(0,'e~')
            point_e.append(".o")
            extension_e= "".join(point_e)
            item.append(extension_e)
            item.append('result.vcd')
            item.append('work-obj93.cf')
            
            for cle in dico.keys():
                
                if cle != "entity": 
                    item.append(cle) 
                    point_o=list(cle)
                    del point_o[-3:]
                    point_o.append('o')
                    extension_o="".join(point_o)
                    item.append(extension_o)
            for file_name in item:
                remove(file_name)
                
        except FileNotFoundError:
            response = BytesIO()
            response.write(b'Erreur de compilation ! ')
        


        

        

        
        

# Declarer les objets de la classe

webServer = http.server.HTTPServer((HOST, PORT), PythonServer)


# Print the URL of the webserver

print("Server started http://%s:%s" % (HOST, PORT))


try:

    # Run the web server

    webServer.serve_forever()

except KeyboardInterrupt:

    # Stop the web server

    webServer.server_close()

    print("The server is stopped.")





